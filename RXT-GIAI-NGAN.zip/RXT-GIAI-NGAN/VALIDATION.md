# Đối chiếu file nguồn 22/09/2026

| Nhóm | Dự toán (đ) | Đã chi (đ) | Chưa chi (đ) |
|---|---:|---:|---:|
| Bồi thường lần đầu | 3.763.781.053.926 | 3.652.020.929.062 | 112.715.572.876 |
| Bổ sung, NVTC | 198.719.183.148 | 178.113.848.714 | 19.649.886.422 |
| Thưởng bàn giao | 10.312.500.000 | 8.542.500.000 | 1.770.000.000 |
| Tạm cư | 11.905.266.691 | 7.152.400.018 | 4.752.866.673 |
| **Tổng** | **3.984.718.003.765** | **3.845.829.677.794** | **138.888.325.971** |

- 885 dòng hồ sơ; 68 hồ sơ chi <50%, gồm 62 hồ sơ chưa chi.
- Sheet2: 22 dòng đối chiếu BS tiền/NVTC không khớp.
- Có 1 hồ sơ lệch theo nhóm dù tổng 4 nhóm vẫn cân bằng; website hiển thị cảnh báo thay vì tự sửa nguồn.
- Tổng từng nhóm khớp các ô tổng Excel dòng 12.
- Đã kiểm tra nhận diện cột khi chèn thêm cột trống; tổng vẫn giữ đúng.
- Đã kiểm tra từ chối số tiền không hợp lệ.

- Đã chạy kiểm tra sinh HTML của 4 trang, tìm kiếm tiếng Việt và escape nội dung.
- Chưa kiểm tra trực quan và thao tác trên trình duyệt: môi trường không có trình duyệt chạy được. Cần mở thử tại máy sử dụng để xác nhận giao diện và bố cục in.
